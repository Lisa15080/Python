from jinja2 import Environment, PackageLoader, select_autoescape
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs
from models.author import Author
from models.currency import Currency
from controllers.databasecontroller import CurrencyRatesCRUD

env = Environment(
    loader=PackageLoader("myapp"),
    autoescape=select_autoescape()
)

template_index = env.get_template("index.html")
template_currencies = env.get_template("currencies.html")

main_author = Author("Nikolai", "P2345")

currencies_list = [
    Currency("840", "USD", "Доллар США", 90, 1),
    Currency("978", "EUR", "Евро", 91, 1),
    Currency("826", "GBP", "Фунт стерлингов", 100, 1),
]

c_r_controller = CurrencyRatesCRUD(currencies_list)


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        query = parse_qs(self.path.rpartition("?")[-1])
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        result = ""

        if "/currency/delete" in self.path:
            try:
                cid = int(query["id"][0])
                c_r_controller._delete(cid)
                result = f"<p>Валюта с id={cid} удалена.</p>"
            except Exception as e:
                result = f"<p>Ошибка удаления: {e}</p>"

        elif "/currency/update" in self.path:
            try:
                for key, val in query.items():
                    char_code = key.upper()
                    value = float(val[0])
                    c_r_controller._update({char_code: value})
                result = f"<p>Обновление завершено: {query}</p>"
            except Exception as e:
                result = f"<p>Ошибка обновления: {e}</p>"

        if self.path.startswith("/currencies"):
            currencies = c_r_controller._read()
            html = template_currencies.render(currencies=currencies)
        else:
            html = template_index.render(
                myapp="Приложение для отслеживания курсов валют",
                author_name=main_author.name,
                group=main_author.group,
                navigation=[{'caption': 'Главная', 'href': "/"},
                            {'caption': 'Список валют', 'href': "/currencies"}],
                result=result
            )

        self.wfile.write(html.encode("utf-8"))


if __name__ == "__main__":
    httpd = HTTPServer(("localhost", 8080), SimpleHTTPRequestHandler)
    print("Server s running on http://localhost:8080")
    httpd.serve_forever()
