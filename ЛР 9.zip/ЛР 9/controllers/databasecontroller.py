import sqlite3

class CurrencyRatesCRUD():
    def __init__(self, currency_rates_obj):
        self.__con = sqlite3.connect(":memory:")
        self.__cursor = self.__con.cursor()
        self.__currency_rates_obj = currency_rates_obj
        self.__createtable()
        self._create()  # создаём начальные записи

    def __createtable(self):
        self.__cursor.execute("""
            CREATE TABLE IF NOT EXISTS currency(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                num_code TEXT NOT NULL,
                char_code TEXT NOT NULL,
                name TEXT NOT NULL,
                value FLOAT,
                nominal INTEGER
            )
        """)
        self.__con.commit()

    def _create(self):
        data = [
            {
                "num_code": c.num_code,
                "char_code": c.char_code,
                "name": c.name,
                "value": c.value,
                "nominal": c.nominal
            } for c in self.__currency_rates_obj
        ]
        sql = """
            INSERT INTO currency(num_code, char_code, name, value, nominal)
            VALUES(:num_code, :char_code, :name, :value, :nominal)
        """
        self.__cursor.executemany(sql, data)
        self.__con.commit()

    def _read(self):
        self.__cursor.execute("SELECT * FROM currency")
        rows = self.__cursor.fetchall()
        result = []
        for r in rows:
            result.append({
                "id": r[0],
                "num_code": r[1],
                "char_code": r[2],
                "name": r[3],
                "value": r[4],
                "nominal": r[5]
            })
        return result

    def _update(self, currency: dict):
        code, value = next(iter(currency.items()))
        sql = "UPDATE currency SET value = :value WHERE char_code = :code"
        self.__cursor.execute(sql, {"value": value, "code": code})
        self.__con.commit()

    def _delete(self, currency_id):
        sql = "DELETE FROM currency WHERE id = ?"
        self.__cursor.execute(sql, (currency_id,))
        self.__con.commit()

    def __del__(self):
        self.__cursor.close()
        self.__con.close()
