# from jinja2 import Environment, PackageLoader, select_autoescape
# from author import Author
# env = Environment(
#     loader=PackageLoader("myapp"),
#     autoescape=select_autoescape()
# )
#
# template = env.get_template("index.html")
#
# main_author = Author('Nikolai Zhukov', 'P3120')
#
#
# print(template.render(myapp="CurrenciesListApp",
#                       navigation=[{'caption': 'Основная страница',
#                                    'href': "https://nickzhukov.ru" }],
#                       author_name = main_author.name,
#                       group = main_author.group
#                       ))
#

from .author import Author
from .currency import Currency
