class User:
    def __init__(self, id: str, name: str):
        self.id = id
        self.name = name

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name:str):
        if isinstance(name, str) and len(name) >=2:
            self.__name = name
        else:
            raise ValueError("Ошибка при задании имени пользователя")

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, id):
        if isinstance(id, str) and len(id) >=1:
            self.__id = id
        else:
            raise ValueError("Ошибка при задании уникального идентификатора")