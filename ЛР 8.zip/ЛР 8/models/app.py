class App:
    def __init__(self, name: str, version: str, author):
        self.name = name
        self.version = version
        self.author = author

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name: str):
        if isinstance(name, str) and len(name) >= 2:
            self.__name = name
        else:
            raise ValueError("Ошибка при задании названия приложения")

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, version: str):
        if isinstance(version, str) and len(version) >= 1:
            self.__version = version
        else:
            raise ValueError("Ошибка при задании версии приложения")

    @property
    def author(self):
        return self.__author

    @author.setter
    def author(self, author):
        from .author import Author
        if isinstance(author, Author):
            self.__author = author
        else:
            raise ValueError("Автор должен быть объектом класса Author")
