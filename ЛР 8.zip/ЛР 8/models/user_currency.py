class UserCurrency:
    def __init__(self, id: str, user_id: str, currency_id: str):
        self.__id = id
        self.__user_id = user_id
        self.__currency_id = currency_id

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, id: str):
        if isinstance(id, str) and len(id) >= 1:
            self.__id = id
        else:
            raise ValueError("id должен быть строкой")

    @property
    def user_id(self):
        return self.__user_id

    @user_id.setter
    def user_id(self, user_id: str):
        if isinstance(user_id, str) and len(user_id) >= 1:
            self.__user_id = user_id
        else:
            raise ValueError("user_id должен быть строкой")

    @property
    def currency_id(self):
        return self.__currency_id

    @currency_id.setter
    def currency_id(self, currency_id: str):
        if isinstance(currency_id, str) and len(currency_id) >= 1:
            self.__currency_id = currency_id
        else:
            raise ValueError("currency_id должен быть строкой")
