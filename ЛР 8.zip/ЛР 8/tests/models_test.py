from models.author import Author
from models.user import User
from models.currency import Currency
from models.user_currency import UserCurrency

def test_author():
    a = Author("Liza", "P3121")
    assert a.name == "Liza"
    assert a.group == "P3121"

def test_user():
    u = User("1", "Alice", "P3121")
    assert u.id == "1"
    assert u.name == "Alice"
    assert u.group == "P3121"

def test_currency():
    c = Currency("R1", "USD", "Dollar", 1, 90.0)
    assert c.id == "R1"
    assert c.char_code == "USD"
    assert c.name == "Dollar"
    assert c.nominal == 1
    assert c.value == 90.0

def test_user_currency():
    x = UserCurrency("1", "2", "R1")
    assert x.id == "1"
    assert x.user_id == "2"
    assert x.currency_id == "R1"
